clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load EggTrainingAndValidation.mat

G = [0 82 84];
for i = 1:10
    Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
    display(Dtimes)
    disp([' Date and time is ' char(Dtimes)] ); 
    XTest = [Data{i}.Xvalidation{1}];
    YTest = [Data{i}.Yvalidation{1}];

    XTrain = [Data{i}.X{1}];
    YTrain = [Data{i}.Y{1}];
    W = lasso(XTrain,YTrain,'Lambda',0.01);

    w = W;
%% testing
pre_y = XTest * w;

rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );


    XTrain = [];
    YTrain = [];
    XTest = [];
    YTest = [];
end
RMSE = mean(rmse);

RMSE_std = std(rmse);
