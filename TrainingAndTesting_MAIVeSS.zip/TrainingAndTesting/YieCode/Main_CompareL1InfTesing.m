clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))
addpath(genpath('SLEP_package_4.1'))

load CellTraining.mat
load CellTesting.mat

XTrain = XX;
YTrain = YY;

G = [0 82 84];
W = CAP(XTrain, YTrain, 0.1, G, Inf);

w = W;
%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);
rmse = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
