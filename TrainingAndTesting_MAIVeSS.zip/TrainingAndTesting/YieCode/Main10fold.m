clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load CellTrainingAndValidation.mat
load Index.mat

decay = 10;
K = 3;
d = zeros([1 K]);
[m2,n2] = size(indexmapping2);
[m3,n3] = size(indexmapping3);


%% run GHSM
Lambda = [0.0001,0.001,0.01,0.1];


for i = 1:length(Lambda)
    lambda = Lambda(i);
            for ii = 1:10
            Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
            display(Dtimes)
            disp([' Date and time is ' char(Dtimes)] ); 

            XTest = [Data{ii}.Xvalidation{1}];
            YTest = [Data{ii}.Yvalidation{1}];
            for p = 1:m2
                inter2(:,p) = Data{ii}.X{1}(:,indexmapping2(p,1)) .* Data{ii}.X{1}(:,indexmapping2(p,2));
                inter2Test(:,p) = XTest(:,indexmapping2(p,1)) .* XTest(:,indexmapping2(p,2));
            end
            for pp = 1:m3
                inter3(:,pp) = Data{ii}.X{1}(:,indexmapping3(pp,1)) .* Data{ii}.X{1}(:,indexmapping3(pp,2)) .* Data{ii}.X{1}(:,indexmapping3(pp,3));
                inter3Test(:,pp) = XTest(:,indexmapping3(pp,1)) .* XTest(:,indexmapping3(pp,2)) .* XTest(:,indexmapping3(pp,3));
            end

            data.Z{1}.mapping = [];
            data.Z{1}.matrix = Data{ii}.X{1};

            data.Z{2}.mapping = indexmapping2;
            data.Z{2}.matrix = inter2;

            data.Z{3}.mapping = indexmapping3;
            data.Z{3}.matrix = inter3;

            data.Y = Data{ii}.Y{1};

            dataTest.Z{1}.mapping = [];
            dataTest.Z{1}.matrix = XTest;

            dataTest.Z{2}.mapping = indexmapping2;
            dataTest.Z{2}.matrix = inter2Test;

            dataTest.Z{3}.mapping = indexmapping3;
            dataTest.Z{3}.matrix = inter3Test;

            dataTest.Y = YTest;


            for k = 1:K
                d(k) = size(data.Z{k}.matrix, 2);
            end

            [E,EIEE] = Algorithm_preparation(data.Z,K,d(1));
            Max_GISTIter = 1000;
            Theta = GHSM(data.Z,data.Y,lambda,decay,K,E,EIEE,Max_GISTIter); 
            
            %% validation
            pre_y = 0;
            for k = 1:K
                pre_y = pre_y + dataTest.Z{k}.matrix*Theta{k};
            end

            rmse(ii) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
            
            XTest = [];
            YTest = [];
            end
            RMSE(i) = mean(rmse);

            RMSE_std(i) = std(rmse);


end
