clear;
clc;
close all;

addpath('Data')

load Data.mat
load index.mat

[m2,n2] = size(indexmapping2);
[m3,n3] = size(indexmapping3);

X = Xtrain;
Y = Ytrain(:,2);
[m1,n1] = size(X);

idx1 = 1:m1;


%% generate testing
temp = 1:m1;
sizeone  = floor(m1/10);
temp1 = randperm(m1);
testingIdx = temp1(1:sizeone);
XTest = X(testingIdx,:);
YTest = Y(testingIdx,:);

%% generate training and validation
XX = X(setdiff(idx1,testingIdx),:);
YY = Y(setdiff(idx1,testingIdx),:);

