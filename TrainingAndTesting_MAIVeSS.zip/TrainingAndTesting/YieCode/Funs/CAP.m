function W = CAP(X, Y, lambda1, G, q)
addpath(genpath('SLEP_package_4.1'));

opts=[];

% Starting point
opts.init=2;        % starting from a zero point

% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=1000;   % maximum number of iterations

% regularization
opts.rFlag=0;       % use ratio

% Normalization
opts.nFlag=0;       % without normalization

opts.ind = G;

opts.q = q;

%W = glLeastR(X, Y, lambda1, opts);
W = glLeastR(X, Y, lambda1, opts);

