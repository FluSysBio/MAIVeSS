clear;
clc;
close all;

addpath('Data')
load EggTraining.mat

D1 = [XX,YY];

[m1,n1] = size(D1);
sizeone  = floor(m1/10);
Testindex1 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex1(i,1):Testindex1(i,2));
    D1XTrain{i} = D1(Trainindex,1:end-1);
    D1YTrain{i} = D1(Trainindex,end);
    D1XTest{i} = D1(Testindex1(i,1):Testindex1(i,2),1:end-1);
    D1YTest{i} = D1(Testindex1(i,1):Testindex1(i,2),end);
    Trainindex = [];
end



for i = 1:10
    Data{i}.X{1} = D1XTrain{i}; 
    Data{i}.Y{1} = D1YTrain{i}; 
end
  
for i = 1:10
    Data{i}.Xvalidation{1} = D1XTest{i};
    Data{i}.Yvalidation{1} = D1YTest{i};
end