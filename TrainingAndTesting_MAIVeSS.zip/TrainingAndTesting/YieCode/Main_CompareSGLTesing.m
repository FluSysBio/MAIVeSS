clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath('LSTMFuns')
addpath(genpath('SLEP_package_4.1'))

load CellTraining.mat
load CellTesting.mat

G = [0 82 84];

W = GroupLasso(XX,YY,0.1,0.1,G);

w = W;

%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);

rmse = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
