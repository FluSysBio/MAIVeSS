clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load TrainingAndValidation.mat



%% run Multi-task Sparse Group Lasso
groups = {[1:86],[87:90]};
GW = [length(groups{1}), length(groups{2})];
GW = sqrt(GW);


lambda1 = [0.01,0.1,0.2,0.5,1,2,5];
lambda2 = [0.01,0.1,0.2,0.5,1,2,5]; 
lambda3 = [0.01,0.1,0.2,0.5,1,2,5]; 

for i = 1:length(lambda1)
    for j = 1:length(lambda2)
        for p = 1:length(lambda3)
            for ii = 1:10
            Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
            display(Dtimes)
            disp([' Date and time is ' char(Dtimes)] ); 
            [Final_W_MTL_sgl, Tar{i}{j,p}] = MTL_GGSL(Data{ii}.Xmtl, Data{ii}.Ymtl, lambda1(i), lambda2(j),lambda3(p), groups, GW);
            Final_W = Final_W_MTL_sgl;
            XTest = [Data{ii}.Xvalidation{1};Data{ii}.Xvalidation{2};Data{ii}.Xvalidation{3};Data{ii}.Xvalidation{4};...
                     Data{ii}.Xvalidation{5};Data{ii}.Xvalidation{6};Data{ii}.Xvalidation{7};Data{ii}.Xvalidation{8}];
            YTest = [Data{ii}.Yvalidation{1};Data{ii}.Yvalidation{2};Data{ii}.Yvalidation{3};Data{ii}.Yvalidation{4};...
                     Data{ii}.Yvalidation{5};Data{ii}.Yvalidation{6};Data{ii}.Yvalidation{7};Data{ii}.Yvalidation{8}];
            %% validation
            W = mean(Final_W,2);
            pre_y = XTest * 0.4* W + XTest * 0.6 * Final_W(:,8);
            pre_yC = zeros(length(YTest),1);
            pre_yC(find(pre_y>2)) = 1;
            YTestC = zeros(length(YTest),1);
            YTestC(find(YTest>2)) = 1;
            rmse(ii) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
            [micro, macro ] = micro_macro_PR( pre_yC , YTestC);
            acc(ii) = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y );
            sen(ii) = macro.recall;
            
            spe(ii)= sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
            pre(ii) = macro.precision;
            
            f1(ii) = macro.fscore;
           
            
            XTest = [];
            YTest = [];
            end
            RMSE{i}(j,p) = mean(rmse);
            ACC{i}(j,p) = mean(acc);
            SEN{i}(j,p) = mean(sen); % recall
            SPE{i}(j,p) = mean(spe);
            PRE{i}(j,p) = mean(pre);
            F1{i}(j,p) = mean(f1);

            RMSE_std{i}(j,p) = std(rmse);
            ACC_std{i}(j,p) = std(acc);
            SEN_std{i}(j,p) = std(sen); % recall
            SPE_std{i}(j,p) = std(spe);
            PRE_std{i}(j,p) = std(pre);
            F1_std{i}(j,p) = std(f1);
        end
    end
end
