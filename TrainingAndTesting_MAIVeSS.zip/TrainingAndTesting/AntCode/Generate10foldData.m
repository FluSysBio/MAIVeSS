clear;
clc;
close all;

addpath('Data')
load Training.mat

D1 = [XXmtl{1},YYmtl{1}];
D2 = [XXmtl{2},YYmtl{2}];
D3 = [XXmtl{3},YYmtl{3}];
D4 = [XXmtl{4},YYmtl{4}];
D5 = [XXmtl{5},YYmtl{5}];
D6 = [XXmtl{6},YYmtl{6}];
D7 = [XXmtl{7},YYmtl{7}];
D8 = [XXmtl{8},YYmtl{8}];

[m1,n1] = size(D1);
sizeone  = floor(m1/10);
Testindex1 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex1(i,1):Testindex1(i,2));
    D1XTrain{i} = D1(Trainindex,1:end-1);
    D1YTrain{i} = D1(Trainindex,end);
    D1XTest{i} = D1(Testindex1(i,1):Testindex1(i,2),1:end-1);
    D1YTest{i} = D1(Testindex1(i,1):Testindex1(i,2),end);
    Trainindex = [];
end

[m1,n1] = size(D2);
sizeone  = floor(m1/10);
Testindex2 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex2(i,1):Testindex2(i,2));
    D2XTrain{i} = D2(Trainindex,1:end-1);
    D2YTrain{i} = D2(Trainindex,end);
    D2XTest{i} = D2(Testindex2(i,1):Testindex2(i,2),1:end-1);
    D2YTest{i} = D2(Testindex2(i,1):Testindex2(i,2),end);  
    Trainindex = [];
end

[m1,n1] = size(D3);
sizeone  = floor(m1/10);
Testindex3 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex3(i,1):Testindex3(i,2));
    D3XTrain{i} = D3(Trainindex,1:end-1);
    D3YTrain{i} = D3(Trainindex,end);
    D3XTest{i} = D3(Testindex3(i,1):Testindex3(i,2),1:end-1);
    D3YTest{i} = D3(Testindex3(i,1):Testindex3(i,2),end);    
    Trainindex = [];
end

[m1,n1] = size(D4);
sizeone  = floor(m1/10);
Testindex4 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];       
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex1(i,1):Testindex1(i,2));
    D4XTrain{i} = D4(Trainindex,1:end-1);
    D4YTrain{i} = D4(Trainindex,end);
    D4XTest{i} = D4(Testindex4(i,1):Testindex4(i,2),1:end-1);
    D4YTest{i} = D4(Testindex4(i,1):Testindex4(i,2),end); 
    Trainindex = [];
end

[m1,n1] = size(D5);
sizeone  = floor(m1/10);
Testindex5 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex5(i,1):Testindex5(i,2));
    D5XTrain{i} = D5(Trainindex,1:end-1);
    D5YTrain{i} = D5(Trainindex,end);
    D5XTest{i} = D5(Testindex5(i,1):Testindex5(i,2),1:end-1);
    D5YTest{i} = D5(Testindex5(i,1):Testindex5(i,2),end);  
    Trainindex = [];
end

[m1,n1] = size(D6);
sizeone  = floor(m1/10);
Testindex6 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];        
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex6(i,1):Testindex6(i,2));
    D6XTrain{i} = D6(Trainindex,1:end-1);
    D6YTrain{i} = D6(Trainindex,end);
    D6XTest{i} = D6(Testindex6(i,1):Testindex6(i,2),1:end-1);
    D6YTest{i} = D6(Testindex6(i,1):Testindex6(i,2),end); 
    Trainindex = [];
end

[m1,n1] = size(D7);
sizeone  = floor(m1/10);
Testindex7 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];        
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex7(i,1):Testindex7(i,2));
    D7XTrain{i} = D7(Trainindex,1:end-1);
    D7YTrain{i} = D7(Trainindex,end);
    D7XTest{i} = D7(Testindex7(i,1):Testindex7(i,2),1:end-1);
    D7YTest{i} = D7(Testindex7(i,1):Testindex7(i,2),end);  
    Trainindex = [];
end

[m1,n1] = size(D8);
sizeone  = floor(m1/10);
Testindex8 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];        
for i = 1:10
    Trainindex = setdiff(1:m1,Testindex8(i,1):Testindex8(i,2));
    D8XTrain{i} = D8(Trainindex,1:end-1);
    D8YTrain{i} = D8(Trainindex,end);
    D8XTest{i} = D8(Testindex8(i,1):Testindex8(i,2),1:end-1);
    D8YTest{i} = D8(Testindex8(i,1):Testindex8(i,2),end);  
    Trainindex = [];
end        

for i = 1:10
    Data{i}.Xmtl{1} = D1XTrain{i}; 
    Data{i}.Ymtl{1} = D1YTrain{i}; 
    Data{i}.Xmtl{2} = D2XTrain{i}; 
    Data{i}.Ymtl{2} = D2YTrain{i};
    Data{i}.Xmtl{3} = D3XTrain{i}; 
    Data{i}.Ymtl{3} = D3YTrain{i};
    Data{i}.Xmtl{4} = D4XTrain{i}; 
    Data{i}.Ymtl{4} = D4YTrain{i};
    Data{i}.Xmtl{5} = D5XTrain{i}; 
    Data{i}.Ymtl{5} = D5YTrain{i};
    Data{i}.Xmtl{6} = D6XTrain{i}; 
    Data{i}.Ymtl{6} = D6YTrain{i};
    Data{i}.Xmtl{7} = D7XTrain{i}; 
    Data{i}.Ymtl{7} = D7YTrain{i};
    Data{i}.Xmtl{8} = D8XTrain{i}; 
    Data{i}.Ymtl{8} = D8YTrain{i};
end
  
for i = 1:10
    Data{i}.Xvalidation{1} = D1XTest{i};
    Data{i}.Yvalidation{1} = D1YTest{i};
    Data{i}.Xvalidation{2} = D2XTest{i};
    Data{i}.Yvalidation{2} = D2YTest{i};
    Data{i}.Xvalidation{3} = D3XTest{i};
    Data{i}.Yvalidation{3} = D3YTest{i};
    Data{i}.Xvalidation{4} = D4XTest{i};
    Data{i}.Yvalidation{4} = D4YTest{i};
    Data{i}.Xvalidation{5} = D5XTest{i};
    Data{i}.Yvalidation{5} = D5YTest{i};
    Data{i}.Xvalidation{6} = D6XTest{i};
    Data{i}.Yvalidation{6} = D6YTest{i};
    Data{i}.Xvalidation{7} = D7XTest{i};
    Data{i}.Yvalidation{7} = D7YTest{i};
    Data{i}.Xvalidation{8} = D8XTest{i};
    Data{i}.Yvalidation{8} = D8YTest{i};
end