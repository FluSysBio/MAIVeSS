function [res] = f1(prec,rec)
%F1 
res = 2 * (prec * rec) / (prec + rec);
end

