clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath('LSTMFuns')

load Training.mat
load Testing.mat

for i =1:8
    W(:,i) = ridge(YYmtl{i},XXmtl{i},5e3);
end
w = mean(W,2);
%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);
pre_yC = zeros(length(YTest),1);
pre_yC(find(pre_y>=2)) = 1;
YTestC = zeros(length(YTest),1);
YTestC(find(YTest>=2)) = 1;
RMSE = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
[micro, macro ] = micro_macro_PR( pre_yC , YTestC);
acc = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y );
sen = macro.recall;
spe = sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
pre = macro.precision;
F1 = macro.fscore;

res = [RMSE,acc,sen,spe,pre,F1];