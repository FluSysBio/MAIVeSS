clear;
clc;
close all;

addpath('Data')

load Data.mat

X = [Xmtl{1};Xmtl{2};Xmtl{3};Xmtl{4};Xmtl{5};Xmtl{6};Xmtl{7};Xmtl{8}];
Y = [Ymtl{1};Ymtl{2};Ymtl{3};Ymtl{4};Ymtl{5};Ymtl{6};Ymtl{7};Ymtl{8}];
[m1,n1] = size(Xmtl{1});
[m2,n2] = size(Xmtl{2});
[m3,n3] = size(Xmtl{3});
[m4,n4] = size(Xmtl{4});
[m5,n5] = size(Xmtl{5});
[m6,n6] = size(Xmtl{6});
[m7,n7] = size(Xmtl{7});
[m8,n8] = size(Xmtl{8});

idx1 = 1:m1;
idx2 = m1+1:m1+m2;
idx3 = m1+m2+1:m1+m2+m3;
idx4 = m1+m2+m3+1:m1+m2+m3+m4;
idx5 = m1+m2+m3+m4+1:m1+m2+m3+m4+m5;
idx6 = m1+m2+m3+m4+m5+1:m1+m2+m3+m4+m5+m6;
idx7 = m1+m2+m3+m4+m5+m6+1:m1+m2+m3+m4+m5+m6+m7;
idx8 = m1+m2+m3+m4+m5+m6+m7+1:m1+m2+m3+m4+m5+m6+m7+m8;

%% generate testing
temp = 1:m1+m2+m3+m4+m5+m6+m7+m8;
sizeone  = floor((m1+m2+m3+m4+m5+m6+m7+m8)/10);
temp1 = randperm(m1+m2+m3+m4+m5+m6+m7+m8);
testingIdx = temp1(1:sizeone);
XTest = X(testingIdx,:);
YTest = Y(testingIdx,:);

%% generate training and validation
XXmtl{1} = X(setdiff(idx1,testingIdx),:);
YYmtl{1} = Y(setdiff(idx1,testingIdx),:);

XXmtl{2} = X(setdiff(idx2,testingIdx),:);
YYmtl{2} = Y(setdiff(idx2,testingIdx),:);

XXmtl{3} = X(setdiff(idx3,testingIdx),:);
YYmtl{3} = Y(setdiff(idx3,testingIdx),:);

XXmtl{4} = X(setdiff(idx4,testingIdx),:);
YYmtl{4} = Y(setdiff(idx4,testingIdx),:);

XXmtl{5} = X(setdiff(idx5,testingIdx),:);
YYmtl{5} = Y(setdiff(idx5,testingIdx),:);

XXmtl{6} = X(setdiff(idx6,testingIdx),:);
YYmtl{6} = Y(setdiff(idx6,testingIdx),:);

XXmtl{7} = X(setdiff(idx7,testingIdx),:);
YYmtl{7} = Y(setdiff(idx7,testingIdx),:);

XXmtl{8} = X(setdiff(idx8,testingIdx),:);
YYmtl{8} = Y(setdiff(idx8,testingIdx),:);