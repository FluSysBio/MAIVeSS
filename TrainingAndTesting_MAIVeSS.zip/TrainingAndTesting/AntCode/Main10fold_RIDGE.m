clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load TrainingAndValidation.mat


for i = 1:10

XTest = [Data{i}.Xvalidation{1};Data{i}.Xvalidation{2};Data{i}.Xvalidation{3};Data{i}.Xvalidation{4};...
                     Data{i}.Xvalidation{5};Data{i}.Xvalidation{6};Data{i}.Xvalidation{7};Data{i}.Xvalidation{8}];
YTest = [Data{i}.Yvalidation{1};Data{i}.Yvalidation{2};Data{i}.Yvalidation{3};Data{i}.Yvalidation{4};...
                     Data{i}.Yvalidation{5};Data{i}.Yvalidation{6};Data{i}.Yvalidation{7};Data{i}.Yvalidation{8}];

    for ii = 1:8
        W(:,ii) = ridge(Data{i}.Ymtl{ii},Data{i}.Xmtl{ii},5e3);
    end
    w = mean(W,2);
%% testing
pre_y = XTest * w;
pre_yC = zeros(length(YTest),1);
pre_yC(find(pre_y>=2)) = 1;
YTestC = zeros(length(YTest),1);
YTestC(find(YTest>=2)) = 1;
rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
[micro, macro ] = micro_macro_PR( pre_yC , YTestC);
acc(i) = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y );
sen(i) = macro.recall;
spe(i) = sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
pre(i) = macro.precision;
f1(i) = macro.fscore;

XTest = [];
YTest = [];
end
RMSE = mean(rmse);
ACC = mean(acc);
SEN = mean(sen); % recall
SPE = mean(spe);
PRE = mean(pre);
F1 = mean(f1);

RMSE_std = std(rmse);
ACC_std = std(acc);
SEN_std = std(sen); % recall
SPE_std = std(spe);
PRE_std = std(pre);
F1_std = std(f1);