clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load TrainingAndValidation.mat


for i = 1:10

    XTest = [Data{i}.Xvalidation{1};Data{i}.Xvalidation{2};Data{i}.Xvalidation{3};Data{i}.Xvalidation{4};...
                     Data{i}.Xvalidation{5};Data{i}.Xvalidation{6};Data{i}.Xvalidation{7};Data{i}.Xvalidation{8}];
    YTest = [Data{i}.Yvalidation{1};Data{i}.Yvalidation{2};Data{i}.Yvalidation{3};Data{i}.Yvalidation{4};...
                     Data{i}.Yvalidation{5};Data{i}.Yvalidation{6};Data{i}.Yvalidation{7};Data{i}.Yvalidation{8}];

    XTrain = [Data{i}.Xmtl{1};Data{i}.Xmtl{2};Data{i}.Xmtl{3};Data{i}.Xmtl{4};Data{i}.Xmtl{5};Data{i}.Xmtl{6};Data{i}.Xmtl{7};Data{i}.Xmtl{8};]';
    YTrain = [Data{i}.Ymtl{1};Data{i}.Ymtl{2};Data{i}.Ymtl{3};Data{i}.Ymtl{4};Data{i}.Ymtl{5};Data{i}.Ymtl{6};Data{i}.Ymtl{7};Data{i}.Ymtl{8};]';
    numResponses = size(YTrain,1);
    numHiddenUnits = 50;
    numFeatures = size(XTrain,1);

    layers = [ ...
    sequenceInputLayer(numFeatures)
    fullyConnectedLayer(10)
    dropoutLayer(0.5)
    fullyConnectedLayer(numResponses)
    regressionLayer];

    maxEpochs = 50;
    miniBatchSize = 10;

    options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.0005, ...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'Plots','training-progress',...
    'Verbose',0);

    net = trainNetwork(XTrain,YTrain,layers,options);

    pre_y = predict(net,XTest','MiniBatchSize',1);
    pre_y = double(pre_y)';
    pre_yC = zeros(length(pre_y),1);
    pre_yC(find(pre_y>=2)) = 1;
    YTestC = zeros(length(YTest),1);
    YTestC(find(YTest>=2)) = 1;
    %rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
    [micro, macro ] = micro_macro_PR( pre_yC , YTestC);
    acc(i) = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y' );
    sen(i) = macro.recall;
    spe(i) = sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
    pre(i) = macro.precision;
    f1(i) = macro.fscore;
    
    XTrain = [];
    YTrain = [];
    XTest = [];
    YTest = [];
end

ACC = mean(acc);
SEN = mean(sen); % recall
SPE = mean(spe);
PRE = mean(pre);
F1 = mean(f1);

ACC_std = std(acc);
SEN_std = std(sen); % recall
SPE_std = std(spe);
PRE_std = std(pre);
F1_std = std(f1);