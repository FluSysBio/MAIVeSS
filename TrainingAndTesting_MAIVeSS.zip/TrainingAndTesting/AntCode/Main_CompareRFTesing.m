clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('Random-Forest-Matlab-master'))
rng(12)
load Training.mat
load Testing.mat
XTrain = [XXmtl{1};XXmtl{2};XXmtl{3};XXmtl{4};XXmtl{5};XXmtl{6};XXmtl{7};XXmtl{8}];
YTrain = [YYmtl{1};YYmtl{2};YYmtl{3};YYmtl{4};YYmtl{5};YYmtl{6};YYmtl{7};YYmtl{8}];
YTrain(find(YTrain < 2)) = 0;
YTrain(find(YTrain >= 2)) = 1;

YTest(find(YTest < 2)) = 0;
YTest(find(YTest >= 2)) = 1;

opts= struct;
opts.depth= 2;
opts.numTrees= 8;

m= forestTrain(XTrain, YTrain, opts);
preds = forestTest(m, XTest);

[micro, macro ] = micro_macro_PR( preds , YTest);
acc = (nnz( ( YTest == 1 ) .* ( preds == 1 ) ) + nnz( ( YTest == 0 ) .* ( preds == 0 ) ) ) / length( preds );
sen = macro.recall;
spe = sum( ( YTest == 0 ) .* ( preds == 0 ) ) / nnz( YTest == 0 );
pre = macro.precision;
F1 = macro.fscore;