clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath('LSTMFuns')
addpath(genpath('SLEP_package_4.1'))

load HETTraining.mat
load HETTesting.mat



G = [0 3 11 27];

for i =1:length(XXmtl)
    W(:,i) = GroupLasso(XXmtl{i},YYmtl{i},100,30,G);
end
w = mean(W,2);


%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);

RMSE = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );

