clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))
addpath(genpath('SLEP_package_4.1'))

load LBTTrainingAndValidation.mat
G = [0 3 11 27];

for i = 1:10

            XTest = [];
            YTest = [];
            for q =1:length(Data{i}.Xvalidation) 
                XTest = [XTest;Data{i}.Xvalidation{q}];
                YTest = [YTest;Data{i}.Yvalidation{q}];
            end

    for ii = 1:length(Data{i}.Xmtl)
        W(:,ii) = GroupLasso(Data{i}.Xmtl{ii},Data{i}.Ymtl{ii},100,30,G);
    end
    w = mean(W,2);
%% testing
pre_y = XTest * w;

rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );


XTest = [];
YTest = [];
end
RMSE = mean(rmse);


RMSE_std = std(rmse);

