clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath('LSTMFuns')

load HETTraining.mat
load HETTesting.mat


for i =1:length(XXmtl)
    W(:,i) = lasso(XXmtl{i},YYmtl{i},'Lambda',0.1);
end
w = mean(W,2);

%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);

RMSE = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
