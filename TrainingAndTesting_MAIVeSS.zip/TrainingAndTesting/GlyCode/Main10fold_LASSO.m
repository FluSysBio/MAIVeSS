clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load LBTTrainingAndValidation.mat

for i = 1:10

            XTest = [];
            YTest = [];
            for q =1:length(Data{i}.Xvalidation) 
                XTest = [XTest;Data{i}.Xvalidation{q}];
                YTest = [YTest;Data{i}.Yvalidation{q}];
            end

for ii = 1:length(Data{i}.Xmtl)
        W(:,ii) = lasso(Data{i}.Xmtl{ii},Data{i}.Ymtl{ii},'Lambda',0.1);
    end
    w = mean(W,2);
%% testing
pre_y = XTest * w;
rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );

XTest = [];
YTest = [];
end
RMSE = mean(rmse);


RMSE_std = std(rmse);
