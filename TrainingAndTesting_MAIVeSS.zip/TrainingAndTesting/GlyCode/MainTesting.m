clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load HETTraining.mat
load HETTesting.mat




%% run Multi-task Sparse Group Lasso
groups = {[1:3],[4:11],[12:27]};
GW = [length(groups{1}), length(groups{2}), length(groups{3})];
GW = sqrt(GW);


lambda1 = 2;
lambda2 = 0.01;
lambda3 = 0.01;

for i = 1:length(lambda1)
    for j = 1:length(lambda2)
        for p = 1:length(lambda3)
            Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
            display(Dtimes)
            disp([' Date and time is ' char(Dtimes)] ); 
            [Final_W_MTL_sgl, Tar{i}{j,p}] = MTL_GGSL(XXmtl, YYmtl, lambda1(i), lambda2(j),lambda3(p), groups, GW);
            Final_W = Final_W_MTL_sgl;
            W = mean(Final_W,2);
            %% testing
            pre_y = XTest * W;
            cor = corr(pre_y,YTest);
            RMSE{i}(j,p) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );

        end
    end
end