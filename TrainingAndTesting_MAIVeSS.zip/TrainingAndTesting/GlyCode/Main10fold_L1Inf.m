clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))
addpath(genpath('SLEP_package_4.1'))

load LBTTrainingAndValidation.mat

for i = 1:10

            XTest = [];
            YTest = [];
            for q =1:length(Data{i}.Xvalidation) 
                XTest = [XTest;Data{i}.Xvalidation{q}];
                YTest = [YTest;Data{i}.Yvalidation{q}];
            end
W = MTL_l1Inf(Data{i}.Xmtl, Data{i}.Ymtl, 0.1);

w = mean(W,2);
%% testing
pre_y = XTest * w;
rmse(i) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );

XTest = [];
YTest = [];
end
RMSE = mean(rmse);


RMSE_std = std(rmse);
