clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load LBTTrainingAndValidation.mat



%% run Multi-task Sparse Group Lasso
groups = {[1:3],[4:11],[12:27]};
GW = [length(groups{1}), length(groups{2}), length(groups{3})];
GW = sqrt(GW);


lambda1 = [0.01,0.1,0.2,0.5,1,2,5];
lambda2 = [0.01,0.1,0.2,0.5,1,2,5]; 
lambda3 = [0.01,0.1,0.2,0.5,1,2,5]; 

for i = 1:length(lambda1)
    for j = 1:length(lambda2)
        for p = 1:length(lambda3)
            for ii = 1:10
            Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
            display(Dtimes)
            disp([' Date and time is ' char(Dtimes)] ); 
            [Final_W_MTL_sgl, Tar{i}{j,p}] = MTL_GGSL(Data{ii}.Xmtl, Data{ii}.Ymtl, lambda1(i), lambda2(j),lambda3(p), groups, GW);
            Final_W = Final_W_MTL_sgl;
            XTest = [];
            YTest = [];
            for q =1:length(Data{ii}.Xvalidation) 
                XTest = [XTest;Data{ii}.Xvalidation{q}];
                YTest = [YTest;Data{ii}.Yvalidation{q}];
            end
            %% validation
            W = mean(Final_W,2);
            pre_y = XTest * W;
            rmse(ii) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
            XTest = [];
            YTest = [];
            end
            RMSE{i}(j,p) = mean(rmse);


            RMSE_std{i}(j,p) = std(rmse);

        end
    end
end
