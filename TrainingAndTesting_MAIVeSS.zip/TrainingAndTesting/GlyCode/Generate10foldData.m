clear;
clc;
close all;

addpath('Data')
load LBTTraining.mat


for i = 1:length(XXmtl)
    D{i} = [XXmtl{i},YYmtl{i}];
    [m1,n1] = size(D{i});
    sizeone  = floor(m1/10);
    Testindex1 = [1,sizeone;sizeone+1,2*sizeone;2*sizeone+1,3*sizeone;3*sizeone+1,4*sizeone;4*sizeone+1,5*sizeone;...
            5*sizeone+1,6*sizeone;6*sizeone+1,7*sizeone;7*sizeone+1,8*sizeone;8*sizeone+1,9*sizeone;9*sizeone+1,m1];
    for ii = 1:10
        Trainindex = setdiff(1:m1,Testindex1(ii,1):Testindex1(ii,2));
        D1XTrain{ii} = D{i}(Trainindex,1:end-1);
        D1YTrain{ii} = D{i}(Trainindex,end);
        D1XTest{ii} = D{i}(Testindex1(ii,1):Testindex1(ii,2),1:end-1);
        D1YTest{ii} = D{i}(Testindex1(ii,1):Testindex1(ii,2),end);
        Trainindex = [];
        Data{ii}.Xmtl{i} = D1XTrain{ii}; 
        Data{ii}.Ymtl{i} = D1YTrain{ii};
        Data{ii}.Xvalidation{i} = D1XTest{ii};
        Data{ii}.Yvalidation{i} = D1YTest{ii};
    end 
    Testindex1 = [];
end