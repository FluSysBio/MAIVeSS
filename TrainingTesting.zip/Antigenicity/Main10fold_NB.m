clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load TrainingAndValidation.mat


for i = 1:10

    XTest = [Data{i}.Xvalidation{1};Data{i}.Xvalidation{2};Data{i}.Xvalidation{3};Data{i}.Xvalidation{4};...
                     Data{i}.Xvalidation{5};Data{i}.Xvalidation{6};Data{i}.Xvalidation{7};Data{i}.Xvalidation{8}];
    YTest = [Data{i}.Yvalidation{1};Data{i}.Yvalidation{2};Data{i}.Yvalidation{3};Data{i}.Yvalidation{4};...
                     Data{i}.Yvalidation{5};Data{i}.Yvalidation{6};Data{i}.Yvalidation{7};Data{i}.Yvalidation{8}];

    XTrain = [Data{i}.Xmtl{1};Data{i}.Xmtl{2};Data{i}.Xmtl{3};Data{i}.Xmtl{4};Data{i}.Xmtl{5};Data{i}.Xmtl{6};Data{i}.Xmtl{7};Data{i}.Xmtl{8};];
    YTrain = [Data{i}.Ymtl{1};Data{i}.Ymtl{2};Data{i}.Ymtl{3};Data{i}.Ymtl{4};Data{i}.Ymtl{5};Data{i}.Ymtl{6};Data{i}.Ymtl{7};Data{i}.Ymtl{8};];

    YTrain(find(YTrain < 2)) = 0;
    YTrain(find(YTrain >= 2)) = 1;

    YTest(find(YTest < 2)) = 0;
    YTest(find(YTest >= 2)) = 1;

    K = max(YTrain);   % determining number of classes [1-K]
    fprintf("Multinomial Log Reg:\n")
    preds = binaryBayesianLogReg(XTrain, XTest, YTrain, YTest, K); % change this func to other ML algorithms
    preds(find(isnan(preds))) = 0;
    preds(find(preds<1)) = 0;
    % evaluate
    [micro, macro ] = micro_macro_PR( preds , YTest);
    acc(i) = (nnz( ( YTest == 1 ) .* ( preds == 1 ) ) + nnz( ( YTest == 0 ) .* ( preds == 0 ) ) ) / length( preds );
    sen(i) = macro.recall;
    spe(i) = sum( ( YTest == 0 ) .* ( preds == 0 ) ) / nnz( YTest == 0 );
    pre(i) = macro.precision;
    f1(i) = macro.fscore;

    XTrain = [];
    YTrain = [];
    XTest = [];
    YTest = [];
end

ACC = mean(acc);
SEN = mean(sen); % recall
SPE = mean(spe);
PRE = mean(pre);
F1 = mean(f1);

ACC_std = std(acc);
SEN_std = std(sen); % recall
SPE_std = std(spe);
PRE_std = std(pre);
F1_std = std(f1);