function [res] = sigmoid(X)
%SIGMOID 
res = (1./(1 + exp(-(X))));

end

