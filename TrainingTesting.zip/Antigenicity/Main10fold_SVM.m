clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load EggTrainingAndValidation.mat


for i = 1:10
    Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
    display(Dtimes)
    disp([' Date and time is ' char(Dtimes)] ); 
    XTest = [Data{i}.Xvalidation{1}];
    YTest = [Data{i}.Yvalidation{1}];

    XTrain = [Data{i}.X{1}];
    YTrain = [Data{i}.Y{1}];

    YTrain(find(YTrain < 1)) = 0;
    YTrain(find(YTrain >= 1)) = 1;

    YTest(find(YTest < 1)) = 0;
    YTest(find(YTest >= 1)) = 1;

    C = 1;
    model = fitcsvm(XTrain,YTrain);
    [~,pre_y] = predictOneVsAll(model.Beta, XTest);

    % evaluate
    acc(i) = (nnz( ( YTest >= 1 ) .* ( pre_y >= 1 ) ) + nnz( ( YTest < 1 ) .* ( pre_y < 1 ) ) ) / length( pre_y );
    sen(i) = sum( ( YTest >= 1 ) .* ( pre_y >= 1 ) ) / nnz( YTest >= 1 );
    spe(i)= sum( ( YTest < 1 ) .* ( pre_y < 1 ) ) / nnz( YTest < 1 );
    pre(i) = sum( ( YTest >= 1 ) .* ( pre_y >= 1 ) )/nnz(pre_y >= 1);
    f1(i) = 2*pre(i)*sen(i)/(pre(i)+sen(i));

end

ACC = mean(acc);
SEN = mean(sen); % recall
SPE = mean(spe);
PRE = mean(pre);
F1 = mean(f1);

ACC_std = std(acc);
SEN_std = std(sen); % recall
SPE_std = std(spe);
PRE_std = std(pre);
F1_std = std(f1);