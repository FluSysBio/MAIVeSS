clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath('LSTMFuns')
rng(1)
load Training.mat
load Testing.mat
XTrain = [XXmtl{1};XXmtl{2};XXmtl{3};XXmtl{4};XXmtl{5};XXmtl{6};XXmtl{7};XXmtl{8}]';
YTrain = [YYmtl{1};YYmtl{2};YYmtl{3};YYmtl{4};YYmtl{5};YYmtl{6};YYmtl{7};YYmtl{8}]';

numResponses = size(YTrain,1);
numHiddenUnits = 50;
numFeatures = size(XTrain,1);

layers = [ ...
    sequenceInputLayer(numFeatures)
    fullyConnectedLayer(10)
    dropoutLayer(0.5)
    fullyConnectedLayer(numResponses)
    regressionLayer];

maxEpochs = 50;
miniBatchSize = 20;

options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.0002, ...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'Plots','training-progress',...
    'Verbose',0);

net = trainNetwork(XTrain,YTrain,layers,options);

pre_y = predict(net,XTest','MiniBatchSize',1);
pre_y = double(pre_y)';
pre_yC = zeros(length(YTest),1);
    pre_yC(find(pre_y>=2)) = 1;
    YTestC = zeros(length(YTest),1);
    YTestC(find(YTest>=2)) = 1;
    RMSE = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
    [micro, macro ] = micro_macro_PR( pre_yC , YTestC);
    acc = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y' );
    sen = macro.recall;
    spe = sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
    pre = macro.precision;
    F1 = macro.fscore;