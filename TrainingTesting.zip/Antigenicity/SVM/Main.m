clear;
clc;
close all;

%% Initialization and reading dataset
addpath('measures')
load fisheriris
X = meas;
for i = 1:150
    if strcmp(string(species(i)),'setosa') == 1
        labels(i,1) = 1;
    elseif strcmp(string(species(i)),'versicolor') == 1
        labels(i,1) = 2;
    elseif strcmp(string(species(i)),'virginica') == 1
        labels(i,1) = 3;
    end
end
    
C = 0.1;
labels(find(labels ~= 1)) = 0;
y = labels;
model = svmTrain(X, y, C, @linearKernel);
preds = svmPredict(model, X);

% evaluate
y_test = y;
rec = recall(preds, y_test); 
prec = precision(preds, y_test); 
f1Meas  = f1(prec,rec); 
fpr = FPR(preds, y_test);