function [prob,target] = predictOneVsAll(all_theta, X)

prob = sigmoid(X * all_theta);
for i =1:length(prob)
    if prob(i) > 0.5
        target(i,1) = 1;
    else
        target(i,1) = 0;
    end
end   
end
