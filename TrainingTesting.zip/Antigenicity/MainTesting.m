clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))

load Training.mat
load Testing.mat
XTrain = [XXmtl{1};XXmtl{2};XXmtl{3};XXmtl{4};XXmtl{5};XXmtl{6};XXmtl{7};XXmtl{8}];
YTrain = [YYmtl{1};YYmtl{2};YYmtl{3};YYmtl{4};YYmtl{5};YYmtl{6};YYmtl{7};YYmtl{8}];


%% run Multi-task Sparse Group Lasso
groups = {[1:86],[87:90]};
GW = [length(groups{1}), length(groups{2})];
GW = sqrt(GW);


lambda1 = 2;
lambda2 = 0.01;
lambda3 = 0.01;

for i = 1:length(lambda1)
    for j = 1:length(lambda2)
        for p = 1:length(lambda3)
            Dtimes=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss Z');
            display(Dtimes)
            disp([' Date and time is ' char(Dtimes)] ); 
            [Final_W_MTL_sgl, Tar{i}{j,p}] = MTL_GGSL(XXmtl, YYmtl, lambda1(i), lambda2(j),lambda3(p), groups, GW);
            Final_W = Final_W_MTL_sgl;
            W = mean(Final_W,2);
            %% testing
            pre_y = XTest * 0.4* W + XTest * 0.6 * Final_W(:,8);
            cor = corr(pre_y,YTest);
            pre_yC = zeros(length(YTest),1);
            pre_yC(find(pre_y>=2)) = 1;
            YTestC = zeros(length(YTest),1);
            YTestC(find(YTest>=2)) = 1;
            RMSE{i}(j,p) = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
            [micro, macro ] = micro_macro_PR( pre_yC , YTestC);
            acc{i}(j,p) = (nnz( ( YTest >= 2 ) .* ( pre_y >= 2 ) ) + nnz( ( YTest < 2 ) .* ( pre_y < 2 ) ) ) / length( pre_y );
            sen{i}(j,p) = macro.recall;
            spe{i}(j,p) = sum( ( YTest < 2 ) .* ( pre_y < 2 ) ) / nnz( YTest < 2 );
            pre{i}(j,p) = macro.precision;
            F1{i}(j,p) = macro.fscore;
        end
    end
end