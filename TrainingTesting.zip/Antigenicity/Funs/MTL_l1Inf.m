function Beta=MTL_l1Inf(X,Y,Lambda1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
currentFolder = pwd;
addpath(genpath(currentFolder));

T=length(X);
N=0;
A=[];
y=[];
for t=1:T
    A=[A;X{t}];
    y=[y;Y{t}];
end
for t=1:T
    opts.ind(t)=N;
    N=N+size(X{t}, 1);
end
opts.ind(T+1)=N;
opts.q = Inf; % 2 or Inf
opts.maxIter = 100;
[W,~,~]=mtLeastR(A,y,Lambda1,opts);
Beta=W;
