function W = GroupLasso(X, Y, lambda1, lambda2, G)
addpath(genpath('SLEP_package_4.1'));

opts=[];

% Starting point
opts.init=2;        % starting from a zero point

% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=500;   % maximum number of iterations

% regularization
opts.rFlag=0;       % use ratio

% Normalization
opts.nFlag=0;       % without normalization

num_G = length(G) - 1;
for g = 1:num_G
    opts.ind(1, g) = G(g) + 1;
    opts.ind(2, g) = G(g+1);
    opts.ind(3, g) = sqrt(G(g+1) - G(g));
end
W = sgLeastR(X, Y, [lambda1 lambda2], opts);