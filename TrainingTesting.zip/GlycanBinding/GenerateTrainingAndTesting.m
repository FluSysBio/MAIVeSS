clear;
clc;
close all;

addpath('Data')

load Data.mat

temp = LBT; % log2 value without normalization, cutoff as 500 (divided by 500), distance should be 3
[m,n] = size(temp);
X = [];
Y = [];
for i = 1:n
    X = [X;X_train];
    Y = [Y;temp(:,n)];
    idx(i,:) = (m*i-m+1):m*i;
end


%% generate testing
sizeone  = floor((m*n)/10);
temp1 = randperm(m*n);
testingIdx = temp1(1:sizeone);
XTest = X(testingIdx,:);
YTest = Y(testingIdx,:);

%% generate training and validation
for i = 1:n
    XXmtl{i} = X(setdiff(idx(i,:),testingIdx),:);
    YYmtl{i} = Y(setdiff(idx(i,:),testingIdx),:);
end

