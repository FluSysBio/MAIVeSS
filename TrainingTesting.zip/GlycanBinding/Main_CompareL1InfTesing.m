clear;
clc;
close all;

%% add path
addpath('Funs')
addpath('Data')
addpath(genpath('multiclass-classification-master-NaiveBayes'))
addpath(genpath('SVM'))
addpath(genpath('RandomForest-main'))
addpath(genpath('SLEP_package_4.1'))

load HETTraining.mat
load HETTesting.mat


W = MTL_l1Inf(XXmtl, YYmtl, 1e4);

w = mean(W,2);
%% testing
pre_y = XTest * w;
cor = corr(pre_y,YTest);

RMSE = sqrt( norm( YTest - pre_y, 2 )^2 / length(YTest) );
